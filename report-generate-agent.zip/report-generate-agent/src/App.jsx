import { useState } from "react";
// import reactLogo from "./assets/react.svg";
// import viteLogo from "/vite.svg";
// import './App.css'
import EquityDashboard from "./EquityDashboard";

function App() {
  const [count, setCount] = useState(0);

  return (
    <>
      <EquityDashboard />
    </>
  );
}

export default App;

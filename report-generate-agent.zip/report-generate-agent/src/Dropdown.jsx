// src/Dropdown.js
import React from "react";
import { Select, MenuItem, FormControl, InputLabel } from "@mui/material";

const SectionTypeDropdown = ({ value, onChange, defaultValue=null }) => {
  const sectionTypes = ["Paragraph", "Table", "Chart"];

  return (
    <FormControl sx={{ width: "140px", marginBottom: 2 }}>
      <InputLabel id="section-type-label" size="small">
        Section Type
      </InputLabel>
      <Select
        labelId="section-type-label"
        // value={value}
        label="Section Type"
        onChange={onChange}
        size="small"
        defaultValue={defaultValue}
      >
        {sectionTypes.map((type) => (
          <MenuItem key={type} value={type}>
            {type}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
};

export default SectionTypeDropdown;

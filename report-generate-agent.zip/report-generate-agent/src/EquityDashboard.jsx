import React, { useState, useEffect } from "react";
import {
  MessageSquare,
  Save,
  Download,
  Plus,
  Settings,
  GripVertical,
  X,
  BarChart,
  FileUp,
  TableOfContents,
  FileText,
  ListEnd,
  MessageSquareDot,
} from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import SectionTypeDropdown from "./Dropdown";
import Box from "@mui/material/Box";
import { Button, Modal, TextField, Typography } from "@mui/material";
import FormControl from "@mui/material/FormControl";
import Avatar from "@mui/material/Avatar";
import Stack from "@mui/material/Stack";
import "./EquityDashboard.css";

// ##############################################################
// Chat Modal page styling
const styleChatModal = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

// ##############################################################
// Sample Reasoning Steps
export const ReasoningSteps = () => {
  return (
    <>
      <ul>
        <li>Analyzed the SEC filing to extract key performance indicators and strategic milestones.</li>
        <li>Summized the complex financial data into a concise narrative suitable for an executive summary.</li>
        <li>Ens that the content aligns with the prompt for clarity and comprehensiveness.</li>
        <li>Extract key financial figures from Microsoft’s annual SEC filings.</li>
        <li>Formatted financial data into a tabular format for ease of analysis.</li>
        <li>Validated numbers with historical data to ensure consistency and accuracy.</li>
      </ul>
    </>
  );
}

// ##############################################################
// Header component
const Header = ({ dateRange, setDateRange }) => (
  <div className="header">
    <div className="header-top">
      <a href="https://www.acuitykp.com" title="Acuity Knowledge Partners">
        <img
          src="https://www.acuitykp.com/wp-content/themes/maks/images/Acuity-logo-homepage.svg"
          alt="Acuity Knowledge Partners"
          width="215"
          height="45"
        />
      </a>
      <div style={{ display: "flex", alignItems: "center" }}>
        <div className="date-range">
          <div className="date-input-container">
            <span className="date-label">Start</span>
            <input type="date" className="date-input" />
          </div>
          <span style={{ marginTop: "20px" }}>-</span>
          <div className="date-input-container">
            <span className="date-label">End</span>
            <input type="date" className="date-input" />
          </div>
        </div>
        <div className="avatar-alignment">
          <Stack direction="row" spacing={2}>
            <a href="#" alert="Profile Settings">
              <Avatar alt="Remy Sharp" src="../src/assets/images/avatar.jpg" />
            </a>
          </Stack>
        </div>
      </div>
    </div>

    <div className="header-content">
      <div style={{ display: "flex", flexDirection: "column" }}>
        <div style={{ display: "flex", alignItems: "center" }}>
          <h1 className="project-title" style={{ marginRight: "5px" }}>
            Project Name
          </h1>
          <span style={{ margin: "0 5px" }}>|</span>
          <h3 className="company-name" style={{ marginLeft: "5px" }}>
            Company Name
          </h3>
        </div>
        <div>
          <p>
            This report provides a comprehensive overview of key market trends,
            performance metrics, and visualized data insights to support
            strategic decision-making. It highlights critical financial
            indicators and actionable insights tailored to the project's
            objectives.
          </p>
        </div>
      </div>
      <div className="button-group">
        <button className="button button-outlined">
          <Save size={18} />
          Save Template
        </button>
        <button className="button button-outlined">
          <FileUp size={18} />
          Export Report
        </button>
      </div>
    </div>

    <div className="divider" />
  </div>
);

const Menu = ({ anchorEl, onClose, children }) => {
  if (!anchorEl) return null;

  const rect = anchorEl.getBoundingClientRect();

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (anchorEl && !anchorEl.contains(event.target)) {
        onClose();
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [anchorEl, onClose]);

  return (
    <>
      <div className="menu-overlay" onClick={onClose} />
      <div
        className="menu"
        style={{
          top: rect.bottom + 8,
          left: rect.left,
        }}
      >
        {children}
      </div>
    </>
  );
};

// ##############################################################
// Draggable Content Section component
const DraggableContentSection = ({
  section,
  onGenerate,
  onDragStart,
  onDragEnd,
  onDragOver,
  onDragLeave, 
  updateSectionContent,
}) => {
  const [menuAnchor, setMenuAnchor] = useState(null);
  const [isDragging, setIsDragging] = useState(false);
  const [sectionType, setSectionType] = useState(section.type);
  // Chat Modal States
  const [openChatModal, setOpenChatModal] = useState(false);
  const handleOpenChatModal = () => setOpenChatModal(true);
  const handleCloseChatModal = () => setOpenChatModal(false);
  const [inputValueChatModal, setInputValueChatModal] = useState("");

  // Reasoning Modal States
  const [openReasoningModal, setOpenReasoningModal] = useState(false);
  const handleOpenReasoningModal = () => setOpenReasoningModal(true);
  const handleCloseReasoningModal = () => setOpenReasoningModal(false);
  const [inputValueReasoningModal, setInputValueReasoningModal] = useState("");

  // Settings Modal States
  const [openSettingsModal, setOpenSettingsModal] = useState(false);
  const handleOpenSettingsModal = () => setOpenSettingsModal(true);
  const handleCloseSettingsModal = () => setOpenSettingsModal(false);
  const [inputValueSettingsModal, setInputValueSettingsModal] = useState("");

  // const [prompt, setPrompt] = useState("");
  // const [keywords, setKeywords] = useState("");
  // const [generatedText, setGeneratedText] = useState("");

  const handleInputChangeChatModal = (event) => {
    setInputValue(event.target.value);
  };

  const handleInputChangeReasoningModal = (event) => {
    setInputValueReasoningModal(event.target.value);
  };

  const handleInputChangeSettingsModal = (event) => {
    setInputValueSettingsModal(event.target.value);
  };

  const handleDragStart = (e) => {
    setIsDragging(true);
    onDragStart(e);
  };

  const handleDragEnd = (e) => {
    setIsDragging(false);
    onDragEnd(e);
  };

  const handleGenerate = () => {
    const newContent = "Generated content comes here..."; // replace with actual generated content
    updateSectionContent(section.id, newContent);
  };

  return (
    <div
      className={`section-card ${isDragging ? "dragging" : ""}`}
      draggable="true"
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      onDragOver={onDragOver}
      onDragLeave={onDragLeave}
    >
      <div className="section-header">
        <div className="section-title">
          <GripVertical className="drag-handle" size={18} />
          {section.title}
        </div>
        <div className="section-actions">
          <button className="icon-button">
            <Save
              size={18}
            />
          </button>
          <Modal
            open={openChatModal}
            onClose={handleCloseChatModal}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
          >
            <Box
              sx={{
                ...styleChatModal,
                border: "2px solid #192073",
                "& .MuiTypography-h6": {
                  color: "#192073",
                },
                borderRadius: "4px",
                p: "16px",
              }}
            >
              <Box display="flex" alignItems="center">
                <MessageSquare size={24} />
                <Typography
                  id="modal-modal-title"
                  variant="h6"
                  component="h2"
                  ml={2}
                >
                  Edit Section Content Prompt
                </Typography>
              </Box>
              <Box mt={2}>
                <TextField
                  fullWidth
                  multiline
                  rows={4}
                  value={inputValueChatModal}
                  onChange={handleInputChangeChatModal}
                  placeholder="Enter your reasoning here..."
                />
              </Box>
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button variant="outlined" onClick={handleCloseChatModal}>
                  Cancel
                </Button>
                <Button
                  variant="contained"
                  color="warning"
                  sx={{
                    backgroundColor: "#f4511e",
                    "&:hover": {
                      backgroundColor: "#f4511e",
                    },
                    ml: 2,
                  }}
                  onClick={() => {
                    // Add your regenerate logic here
                  }}
                >
                  Regenerate
                </Button>
              </Box>
            </Box>
          </Modal>
          <button className="icon-button" onClick={handleOpenSettingsModal}>
            <Settings size={18} alt="Settings" />
          </button>
          <Modal
            open={openSettingsModal}
            onClose={handleCloseSettingsModal}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
          >
            <Box
              sx={{
                ...styleChatModal,
                border: "2px solid #192073",
                "& .MuiTypography-h6": {
                  color: "#192073",
                },
                borderRadius: "4px",
                p: "16px",
                mt: 2,
              }}
            >
              <Box display="flex" alignItems="center">
                <Settings size={24} />
                <Typography
                  id="modal-modal-title"
                  variant="h6"
                  component="h2"
                  ml={2}
                >
                  Enter Type, Prompt
                </Typography>
              </Box>
              <Box
                component="form"
                sx={{ "& > :not(style)": { m: 1, width: "25ch" } }}
                noValidate
                autoComplete="off"
              >
                <SectionTypeDropdown
                  value={sectionType}
                  onChange={(e) => setSectionType(e.target.value)}
                />
                <TextField
                  id="outlined-basic"
                  label="Prompt"
                  variant="outlined"
                  size="small"
                  multiline={true}
                  style={{ width: "98%" }}
                ></TextField>
                <TextField
                  id="outlined-basic"
                  label="Keywords"
                  variant="outlined"
                  size="small"
                  style={{ width: "98%" }}
                >
                  {section.keywords.join(", ")}
                </TextField>
              </Box>
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button variant="outlined" onClick={handleCloseSettingsModal}>
                  Cancel
                </Button>
                <Button
                  variant="contained"
                  color="warning"
                  sx={{
                    backgroundColor: "#f4511e",
                    "&:hover": {
                      backgroundColor: "#f4511e",
                    },
                    ml: 2,
                  }}
                  onClick={handleGenerate}
                >
                  Generate
                </Button>
              </Box>
            </Box>
          </Modal>
          {/* <Menu anchorEl={menuAnchor} onClose={() => setMenuAnchor(null)}>
            <div
              className="menu-item"
              onClick={() => {
                onGenerate(section.id);
                setMenuAnchor(null);
              }}
            >
              <MessageSquare size={18} />
              Get Analysis
            </div>
            <div className="menu-item">
              <BarChart size={18} />
              View Statistics
            </div>
            <div className="menu-item">
              <FileText size={18} />
              Export Section
            </div>
          </Menu> */}
          <button className="icon-button">
            <X size={18} alt="Remove Section" />
          </button>
        </div>
      </div>
      <div className="section-content">
        <Box
          component="form"
          sx={{ "& > :not(style)": { m: 1, width: "25ch" } }}
          noValidate
          autoComplete="off"
        >
          <div className="content-box" style={{ width: "90%", height: "80%" }}>
            {section.content}
          </div>
          <button
            className="button button-outlined"
            style={{
              width: "30%",
              fontSize: "12px",
              padding: "4px 8px",
              float: "right",
              marginRight: "-5px",
            }}
            onClick={(e) => {
              e.preventDefault();
              handleOpenReasoningModal();
            }}
          >
            <ListEnd size={18} /> Reasoning
          </button>
          <Modal
            open={openReasoningModal}
            onClose={handleCloseReasoningModal}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
          >
            <Box
              sx={{
                ...styleChatModal,
                border: "2px solid #192073",
                "& .MuiTypography-h6": {
                  color: "#192073",
                },
                borderRadius: "4px",
                p: "16px",
              }}
            >
              <Box display="flex" alignItems="center">
                <ListEnd size={24} />
                <Typography
                  id="modal-modal-title"
                  variant="h6"
                  component="h2"
                  ml={2}
                >
                  Reasoning Steps
                </Typography>
              </Box>
              <Box mt={2}>
                <div className="content-box" style={{ width: "90%" }}>
                  <ReasoningSteps />
                </div>
              </Box>
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button variant="outlined" onClick={handleCloseReasoningModal}>
                  Close
                </Button>
              </Box>
            </Box>
          </Modal>
          <button
            className="button button-outlined"
            style={{
              width: "30%",
              fontSize: "12px",
              padding: "4px 8px",
              float: "right",
            }}
            onClick={(e) => {
              e.preventDefault();
              handleOpenChatModal();
            }}
          >
            <MessageSquareDot size={18} /> Chat
          </button>
        </Box>
      </div>
    </div>
  );
};

// ##############################################################
// Sample chart data
const chart_data = [
  {
    name: "Page A",
    uv: 4000,
    pv: 2400,
    amt: 2400,
  },
  {
    name: "Page B",
    uv: 3000,
    pv: 1398,
    amt: 2210,
  },
  {
    name: "Page C",
    uv: 2000,
    pv: 9800,
    amt: 2290,
  },
  {
    name: "Page D",
    uv: 2780,
    pv: 3908,
    amt: 2000,
  },
  {
    name: "Page E",
    uv: 1890,
    pv: 4800,
    amt: 2181,
  },
  {
    name: "Page F",
    uv: 2390,
    pv: 3800,
    amt: 2500,
  },
  {
    name: "Page G",
    uv: 3490,
    pv: 4300,
    amt: 2100,
  },
];

// ##############################################################
// Line chart component
const LineChartSection = () => {
  return (
    <>
      <LineChart
        width={730}
        height={250}
        data={chart_data}
        margin={{ top: 10, right: 0, left: 0, bottom: 5 }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="pv" stroke="#8884d8" />
        <Line type="monotone" dataKey="uv" stroke="#82ca9d" />
      </LineChart>
    </>
  );
};

// ##############################################################
// get browser window width
const useWindowWidth = () => {
  const [width, setWidth] = useState(window.innerWidth);

  useEffect(() => {
    const handleResize = () => setWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return width;
};

// ##############################################################
// Chart Section component 
const ChartSection = ({ section, onGenerate }) => {
  const [menuAnchor, setMenuAnchor] = useState(null);
  const [sectionType, setSectionType] = useState(section.type);

  // Add state for chat modal
  const [openChatModal, setOpenChatModal] = useState(false);
  const [inputValueChatModal, setInputValueChatModal] = useState("");

    // Reasoning Modal States
    const [openReasoningModal, setOpenReasoningModal] = useState(false);
    const handleOpenReasoningModal = () => setOpenReasoningModal(true);
    const handleCloseReasoningModal = () => setOpenReasoningModal(false);
    const [inputValueReasoningModal, setInputValueReasoningModal] = useState("");

      // Settings Modal States
  const [openSettingsModal, setOpenSettingsModal] = useState(false);
  const handleOpenSettingsModal = () => setOpenSettingsModal(true);
  const handleCloseSettingsModal = () => setOpenSettingsModal(false);
  const [inputValueSettingsModal, setInputValueSettingsModal] = useState("");

  const width = useWindowWidth();

  // Add handlers for chat modal
  const handleOpenChatModal = () => {
    setOpenChatModal(true);
  };

  const handleCloseChatModal = () => {
    setOpenChatModal(false);
  };

  const handleInputChangeChatModal = (event) => {
    setInputValueChatModal(event.target.value);
  };

  const chartData = section.data?.length
    ? section.data
    : [
      { name: "Jan", value: 100 },
      { name: "Feb", value: 120 },
      { name: "Mar", value: 110 },
      { name: "Apr", value: 140 },
      { name: "May", value: 160 },
      { name: "Jun", value: 150 },
    ];

  return (
    <div className="section-card">
      <div className="section-header">
        <div className="section-title">
          <GripVertical className="drag-handle" size={18} />
          {section.title}
        </div>
        <div className="section-actions">
          <button className="icon-button" onClick={handleOpenChatModal}>
            <Save size={18} />
          </button>
          {/* Modal component */}
          <Modal
            open={openChatModal}
            onClose={handleCloseChatModal}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
          // BackdropProps={{
          //   onClick: null // This prevents closing on backdrop click
          // }}
          >
            <Box
              sx={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                width: 400,
                bgcolor: 'background.paper',
                border: '2px solid #192073',
                borderRadius: '4px',
                boxShadow: 24,
                p: 4,
              }}
            >
              <Box display="flex" alignItems="center">
                <MessageSquare size={24} />
                <Typography
                  id="modal-modal-title"
                  variant="h6"
                  component="h2"
                  ml={2}
                  sx={{ color: '#192073' }}
                >
                  Edit Section Content Prompt
                </Typography>
              </Box>
              <Box mt={2}>
                <TextField
                  fullWidth
                  multiline
                  rows={4}
                  value={inputValueChatModal}
                  onChange={handleInputChangeChatModal}
                  placeholder="Enter your reasoning here..."
                />
              </Box>
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button
                  variant="outlined"
                  onClick={handleCloseChatModal}
                  sx={{ mr: 2 }}
                >
                  Cancel
                </Button>
                <Button
                  variant="contained"
                  sx={{
                    backgroundColor: "#f4511e",
                    "&:hover": {
                      backgroundColor: "#f4511e",
                    },
                  }}
                  onClick={() => {
                    // Add your regenerate logic here
                    handleCloseChatModal();
                  }}
                >
                  Regenerate
                </Button>
              </Box>
            </Box>
          </Modal>
          <button className="icon-button" onClick={handleOpenSettingsModal}>
            <Settings size={18} alt="Settings" />
          </button>
          <Modal
            open={openSettingsModal}
            onClose={handleCloseSettingsModal}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
          >
            <Box
              sx={{
                ...styleChatModal,
                border: "2px solid #192073",
                "& .MuiTypography-h6": {
                  color: "#192073",
                },
                borderRadius: "4px",
                p: "16px",
                mt: 2,
              }}
            >
              <Box display="flex" alignItems="center">
                <Settings size={24} />
                <Typography
                  id="modal-modal-title"
                  variant="h6"
                  component="h2"
                  ml={2}
                >
                  Enter Type, Prompt
                </Typography>
              </Box>
              <Box
                component="form"
                sx={{ "& > :not(style)": { m: 1, width: "25ch" } }}
                noValidate
                autoComplete="off"
              >
                <SectionTypeDropdown
                  value={sectionType}
                  onChange={(e) => setSectionType(e.target.value)}
                />
                <TextField
                  id="outlined-basic"
                  label="Prompt"
                  variant="outlined"
                  size="small"
                  multiline={true}
                  style={{ width: "98%" }}
                ></TextField>
                <TextField
                  id="outlined-basic"
                  label="Keywords"
                  variant="outlined"
                  size="small"
                  style={{ width: "98%" }}
                >
                  {section.keywords.join(", ")}
                </TextField>
              </Box>
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button variant="outlined" onClick={handleCloseSettingsModal}>
                  Cancel
                </Button>
                <Button
                  variant="contained"
                  color="warning"
                  sx={{
                    backgroundColor: "#f4511e",
                    "&:hover": {
                      backgroundColor: "#f4511e",
                    },
                    ml: 2,
                  }}
                  onClick={() => {
                    // Add your regenerate logic here
                  }}
                >
                  Generate
                </Button>
              </Box>
            </Box>
          </Modal>
          {/* <button
            className="icon-button"
            onClick={(e) => setMenuAnchor(e.currentTarget)}
          >
            <Settings size={18} />
          </button>
          <Menu anchorEl={menuAnchor} onClose={() => setMenuAnchor(null)}>
            <div
              className="menu-item"
              onClick={() => {
                onGenerate(section.id);
                setMenuAnchor(null);
              }}
            >
              <MessageSquare size={18} />
              Update Chart
            </div>
            <div className="menu-item">
              <BarChart size={18} />
              Change Chart Type
            </div>
            <div className="menu-item">
              <FileText size={18} />
              Export Chart
            </div>
          </Menu> */}
          <button className="icon-button">
            <X size={18} />
          </button>
        </div>
      </div>
      <div className="section-content">
        <Box
          component="form"
          sx={{ "& > :not(style)": { m: 1, width: "25ch" } }}
          noValidate
          autoComplete="off"
        >
          {/* <SectionTypeDropdown
            value={sectionType}
            onChange={(e) => setSectionType(e.target.value)}
            defaultValue="Chart"
          />
          <TextField
            id="outlined-basic"
            label="Prompt"
            variant="outlined"
            size="small"
            multiline={true}
            style={{ width: "98%" }}
          />
          <TextField
            id="outlined-basic"
            label="Keywords"
            variant="outlined"
            size="small"
            style={{ width: "98%" }}
          >
            {section.keywords?.join(", ")}
          </TextField> */}
          <h4><span className="sub-title-line-prefix">|</span>Financial Growth Trends</h4>
          <LineChartSection />
          <button
            className="button button-outlined"
            style={{
              width: width < 768 ? '17vw' : '14%',
              fontSize: "12px",
              padding: "4px 8px",
              float: "right",
            }}
            onClick={(e) => {
              e.preventDefault();
              handleOpenReasoningModal();
            }}
          >
            <ListEnd size={18} /> Reasoning
          </button>
          <Modal
            open={openReasoningModal}
            onClose={handleCloseReasoningModal}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
          >
            <Box
              sx={{
                ...styleChatModal,
                border: "2px solid #192073",
                "& .MuiTypography-h6": {
                  color: "#192073",
                },
                borderRadius: "4px",
                p: "16px",
              }}
            >
              <Box display="flex" alignItems="center">
                <ListEnd size={24} />
                <Typography
                  id="modal-modal-title"
                  variant="h6"
                  component="h2"
                  ml={2}
                >
                  Reasoning Steps
                </Typography>
              </Box>
              <Box mt={2}>
                <div className="content-box" style={{ width: "90%" }}>
                  <ReasoningSteps />
                </div>
              </Box>
              <Box display="flex" justifyContent="flex-end" mt={2}>
                <Button variant="outlined" onClick={handleCloseReasoningModal}>
                  Close
                </Button>
              </Box>
            </Box>
          </Modal>
          <button
            className="button button-outlined"
            style={{
              width: width < 768 ? '13vw' : '12%',
              fontSize: "12px",
              padding: "4px 8px",
              float: "right",
            }}
            onClick={(e) => {
              e.preventDefault();
              handleOpenChatModal();
            }}
          >
            <MessageSquareDot size={18} /> Chat
          </button>
          <br />
          <br />
        </Box>
      </div>
    </div >
  );
};

// ##############################################################
// Footer
const Footer = () => (
  <div className="footer">
    <button className="button button-contained">
      <Plus size={18} />
      Add Section
    </button>
    <div className="button-group">
      <div className="section-actions">
        <button className="button button-outlined" size="small">
          <Save size={18} /> Save Template
        </button>
        <button className="button button-outlined" size="small">
          <TableOfContents size={18} /> Generate All Content
        </button>
        <button className="button button-outlined" size="small">
          <FileUp size={18} /> Export Report
        </button>
      </div>
    </div>
  </div>
);

// ##############################################################
// EquityDashboard - main component
const EquityDashboard = () => {
  const [dateRange, setDateRange] = useState("Last 12 Months");
  const [sections, setSections] = useState([
    {
      id: 1,
      type: "paragraph",
      title: "Market Overview",
      content: "Click on settings to generate content",
      keywords: ["market", "trends", "analysis"],
      isGenerating: false,
      order: 0,
    },
    {
      id: 2,
      type: "table",
      title: "Key Metrics",
      content: "Click on settings to generate content",
      keywords: ["metrics", "performance", "ratios"],
      isGenerating: false,
      order: 1,
    },
    {
      id: 3,
      type: "chart",
      title: "Performance Visualization",
      data: [
        { name: "Jan", value: 100 },
        { name: "Feb", value: 120 },
        { name: "Mar", value: 110 },
        { name: "Apr", value: 140 },
        { name: "May", value: 160 },
        { name: "Jun", value: 150 },
      ],
      keywords: ["performance", "trends", "visualization"],
      isGenerating: false,
    },
  ]);

  const updateSectionContent = (sectionId, newContent) => {
    setSections((prevSections) => {
      const updatedSections = [...prevSections];
      const sectionIndex = updatedSections.findIndex((section) => section.id === sectionId);
      if (sectionIndex !== -1) {
        updatedSections[sectionIndex].content = newContent;
      }
      return updatedSections;
    });
  };

  const [draggedSection, setDraggedSection] = useState(null);

  const handleDragStart = (e, sectionId) => {
    setDraggedSection(sectionId);
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDragEnd = () => {
    setDraggedSection(null);
    document.querySelectorAll(".section-card").forEach((card) => {
      card.classList.remove("drag-over");
    });
  };

  const handleDragOver = (e, targetSectionId) => {
    e.preventDefault();
    e.currentTarget.classList.add("drag-over");

    if (draggedSection === null || draggedSection === targetSectionId) return;

    setSections((prevSections) => {
      const updatedSections = [...prevSections];
      const draggedIdx = updatedSections.findIndex(
        (s) => s.id === draggedSection
      );
      const targetIdx = updatedSections.findIndex(
        (s) => s.id === targetSectionId
      );

      const draggedOrder = updatedSections[draggedIdx].order;
      updatedSections[draggedIdx].order = updatedSections[targetIdx].order;
      updatedSections[targetIdx].order = draggedOrder;

      return updatedSections;
    });
  };

  const handleDragLeave = (e) => {
    e.currentTarget.classList.remove("drag-over");
  };

  const handleGenerate = (sectionId) => {
    setSections(
      sections.map((section) =>
        section.id === sectionId ? { ...section, isGenerating: true } : section
      )
    );
    setTimeout(() => {
      setSections(
        sections.map((section) =>
          section.id === sectionId
            ? { ...section, isGenerating: false }
            : section
        )
      );
    }, 2000);
  };

  const topSections = sections
    .filter((s) => s.id <= 2)
    .sort((a, b) => a.order - b.order);

  return (
    <div className="dashboard-container">
      <div className="dashboard">
        <Header dateRange={dateRange} setDateRange={setDateRange} />

        <div className="sections-container">
          {topSections.map((section) => (
            <DraggableContentSection
              key={section.id}
              section={section}
              onGenerate={handleGenerate}
              onDragStart={(e) => handleDragStart(e, section.id)}
              onDragEnd={handleDragEnd}
              onDragOver={(e) => handleDragOver(e, section.id)}
              onDragLeave={handleDragLeave} 
              updateSectionContent={updateSectionContent}
            />
          ))}
        </div>

        <ChartSection section={sections[2]} onGenerate={handleGenerate} />

        <Footer />
      </div>
    </div>
  );
};

export default EquityDashboard;
